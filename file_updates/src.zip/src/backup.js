<Carousel className="pic2">
                  <div>
                      <img src={pic2} />
                  </div>
                  <div>
                      <img src={pic3} />
                  </div>
                  <div>
                      <img src={pic4} />
                  </div>
                </Carousel>

                import { Carousel } from 'react-responsive-carousel';
                import "react-responsive-carousel/lib/styles/carousel.min.css";