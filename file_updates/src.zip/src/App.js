import React, { Component } from 'react';
import logo from './logo.png';
import dropdownMenu from './dropdown.png';
import blankavatar from './blankavatar.png'; 
import pic1 from './pic1.jpg' 
import pic2 from './pic2.jpg' 
import pic3 from './pic3.jpg' 
import pic4 from './pic4.jpg' 
import map1 from './losbanos.png'
import './App.css';
import elementType from 'prop-types-extra/lib/elementType';
import Button from 'react-bootstrap/Button';
import Carousel from 'react-bootstrap/Carousel';
import Form from 'react-bootstrap/Form';
import Rater from 'react-rater';
import 'react-rater/lib/react-rater.css';

class App extends Component {
  render() {
    return (
    	<div className="App">
        	<header className="App-header">
        		<div className="clogo">
             		<img src={logo} className="logopic" /> 
            	</div>
    
      			<div class="dropdown show" className="cdropdown">
  					<a class="btn btn-danger dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" className="dropdown">
    					<img src={dropdownMenu} className="dropdownpic" /> 
  					</a>
  					<div class="dropdown-menu">
    					<a class="dropdown-item" href="#">Log-in</a>
   		 				<a class="dropdown-item" href="#">Sign-up</a>
    					<a class="dropdown-item" href="#">View all Restaurants</a>
  					</div>
  				</div>
        	</header>

          <body className="App-body">
            <div className="mainContainer">
            	<div className="titleContainer">
            		<div className="avatarContainer">
            			<img src={blankavatar} className="blankavatar" />
            		</div>
            		<div className="resDetails">
            			<div className="resName">
            				<h2>*name of restaurant*</h2>
            				<h1><Rater id="rate-this-interactive" total={5} rating={2.5} interactive={false} /></h1>	
            			</div>
            		</div>
            	</div>
            </div>

          	<div className="picMapContainer">
          		<div className="picContainer">
          			<div className="carouselContainer">
	          			<Carousel>
						  <Carousel.Item>
						    <img className="slidePic"
						      src={pic2}
						    />
						  </Carousel.Item>
						  <Carousel.Item>
						    <img
						      className="slidePic"
						      src={pic3}
						    />
						  </Carousel.Item>
						  <Carousel.Item>
						    <img
						      className="slidePic"
						      src={pic4}
						    />
						  </Carousel.Item>
						</Carousel>
					</div>
          		</div>
          		<div className="mapContainer">
          			<img src={map1} className="map"/>
          		</div>
            </div>


            <div className="commentContainer">
            	<div className="rating">
	              <h3> Rate this restaurant! </h3>
	              <h1><Rater id="rate-this-interactive" total={5} rating={0} interactive={true} /></h1>
	              <a href="##"><Button variant="warning" type="submit"> Submit Rating </Button></a>
	            </div>
              <Form>
				  <Form.Group controlId="comment">
					  <Form.Control componentClass="textarea" style={{ height: 80 }} placeholder="Add a comment..." />
					  <div className="commentButton">
				      	<a href="###"><Button variant="primary" type="submit"> Comment </Button></a>
				      </div>
				  </Form.Group>
              </Form>;
            </div>
          </body>
      </div>

    );    
  }
}

export default App;
